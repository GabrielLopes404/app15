import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../../constants/theme';
import ProductCard from '../../components/ProductCard';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import { stores, products, services } from '../../constants/mockData';

const { width } = Dimensions.get('window');

function TabButton({ title, active, onPress }) {
  return (
    <TouchableOpacity
      style={[styles.tabButton, active && styles.tabButtonActive]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <Text style={[styles.tabButtonText, active && styles.tabButtonTextActive]}>
        {title}
      </Text>
    </TouchableOpacity>
  );
}

export default function StoreScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [activeTab, setActiveTab] = useState('produtos');
  
  const store = stores[0];

  return (
    <View style={styles.container}>
      <Image
        source={{ uri: store.image }}
        style={styles.heroImage}
        resizeMode="cover"
      />
      
      <SafeAreaView style={styles.header} edges={['top']}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
          activeOpacity={0.8}
        >
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.favoriteButton} activeOpacity={0.8}>
          <Ionicons name="heart-outline" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
      </SafeAreaView>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.storeInfo}>
          <View style={styles.storeHeader}>
            <Text style={styles.storeName}>{store.name}</Text>
            <Badge text={store.isOpen ? 'Aberto' : 'Fechado'} variant={store.isOpen ? 'success' : 'error'} />
          </View>
          
          <View style={styles.storeMeta}>
            <View style={styles.metaItem}>
              <Ionicons name="star" size={16} color={Colors.rating} />
              <Text style={styles.metaText}>{store.rating.toFixed(1)}</Text>
            </View>
            <View style={styles.metaItem}>
              <Ionicons name="location-outline" size={16} color={Colors.textSecondary} />
              <Text style={styles.metaText}>{store.distance} km</Text>
            </View>
            {store.deliveryTime && (
              <View style={styles.metaItem}>
                <Ionicons name="time-outline" size={16} color={Colors.textSecondary} />
                <Text style={styles.metaText}>{store.deliveryTime} min</Text>
              </View>
            )}
          </View>

          <View style={styles.storeTags}>
            {store.tags.map((tag, index) => (
              <Text key={index} style={styles.storeTag}>{tag}</Text>
            ))}
          </View>
        </View>

        <View style={styles.tabs}>
          <TabButton title="Produtos" active={activeTab === 'produtos'} onPress={() => setActiveTab('produtos')} />
          <TabButton title="Serviços" active={activeTab === 'servicos'} onPress={() => setActiveTab('servicos')} />
          <TabButton title="Avaliações" active={activeTab === 'avaliacoes'} onPress={() => setActiveTab('avaliacoes')} />
          <TabButton title="Info" active={activeTab === 'info'} onPress={() => setActiveTab('info')} />
        </View>

        <View style={styles.tabContent}>
          {activeTab === 'produtos' && (
            <View>
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={() => router.push('/cart')}
                />
              ))}
            </View>
          )}

          {activeTab === 'servicos' && (
            <View>
              {services.map((service) => (
                <View key={service.id} style={styles.serviceCard}>
                  <View style={styles.serviceInfo}>
                    <Text style={styles.serviceName}>{service.name}</Text>
                    <Text style={styles.serviceDescription}>{service.description}</Text>
                    <View style={styles.serviceFooter}>
                      <Text style={styles.servicePrice}>R$ {service.price.toFixed(2)}</Text>
                      <Text style={styles.serviceDuration}>{service.duration}</Text>
                    </View>
                  </View>
                  <Button
                    title="Agendar"
                    variant="accent"
                    size="small"
                    onPress={() => router.push('/booking')}
                  />
                </View>
              ))}
            </View>
          )}

          {activeTab === 'avaliacoes' && (
            <View style={styles.emptyState}>
              <Ionicons name="star-outline" size={60} color={Colors.textSecondary} />
              <Text style={styles.emptyText}>Sem avaliações ainda</Text>
            </View>
          )}

          {activeTab === 'info' && (
            <View style={styles.infoContent}>
              <Text style={styles.infoTitle}>Sobre a loja</Text>
              <Text style={styles.infoText}>
                Loja especializada em produtos e serviços para pets, com atendimento de qualidade e produtos premium.
              </Text>
              
              <Text style={styles.infoTitle}>Endereço</Text>
              <Text style={styles.infoText}>Rua das Flores, 123 - Centro</Text>
              
              <Text style={styles.infoTitle}>Horário de funcionamento</Text>
              <Text style={styles.infoText}>Segunda a Sábado: 8h às 20h</Text>
              <Text style={styles.infoText}>Domingo: 9h às 18h</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  heroImage: {
    width: width,
    height: 240,
    backgroundColor: Colors.backgroundGray,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    zIndex: 10,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.backgroundLight,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.medium,
  },
  favoriteButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.backgroundLight,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.medium,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: Spacing.xxxl,
  },
  storeInfo: {
    backgroundColor: Colors.backgroundLight,
    padding: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  storeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  storeName: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    flex: 1,
    marginRight: Spacing.md,
  },
  storeMeta: {
    flexDirection: 'row',
    gap: Spacing.lg,
    marginBottom: Spacing.md,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  metaText: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  storeTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.xs,
  },
  storeTag: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
    backgroundColor: Colors.backgroundGray,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: Colors.backgroundLight,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    gap: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tabButton: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabButtonActive: {
    borderBottomColor: Colors.primary,
  },
  tabButtonText: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    fontWeight: FontWeights.medium,
  },
  tabButtonTextActive: {
    color: Colors.primary,
    fontWeight: FontWeights.semibold,
  },
  tabContent: {
    padding: Spacing.lg,
  },
  serviceCard: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.lg,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    ...Shadows.small,
  },
  serviceInfo: {
    flex: 1,
    marginRight: Spacing.md,
  },
  serviceName: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  serviceDescription: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    marginBottom: Spacing.sm,
  },
  serviceFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  servicePrice: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.primary,
  },
  serviceDuration: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.xxxl,
  },
  emptyText: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    marginTop: Spacing.lg,
  },
  infoContent: {
    gap: Spacing.md,
  },
  infoTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginTop: Spacing.md,
  },
  infoText: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    lineHeight: 22,
  },
});
