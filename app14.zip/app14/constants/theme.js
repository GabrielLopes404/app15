export const Colors = {
  // PALETA AZUL E LARANJA - Vibrante e Moderna
  // Cores Principais - Azul Corporativo
  primary: '#1976D2',           // Azul vibrante - Principal
  primaryDark: '#0D47A1',       // Azul escuro - Estados ativos
  primaryLight: '#42A5F5',      // Azul médio - Hover states
  primarySurface: '#E3F2FD',    // Surface azul suave
  primaryHover: '#1565C0',      // Hover para botões
  primaryPressed: '#0D47A1',    // Pressed state
  
  // Laranja - Accent Color
  accent: '#FF9800',            // Laranja vibrante - CTAs e destaques
  accentDark: '#F57C00',        // Laranja escuro - Hover
  accentLight: '#FFE0B2',       // Laranja claro - Backgrounds
  accentGlow: 'rgba(255, 152, 0, 0.2)',
  
  // Azul Claro - Secundária
  secondary: '#03A9F4',         // Azul claro - Elementos secundários
  secondaryDark: '#0288D1',     // Azul claro escuro
  secondaryLight: '#4FC3F7',    // Azul claro suave
  
  // Backgrounds Limpos
  background: '#FFFFFF',        // Branco puro - Background principal
  backgroundLight: '#FAFBFD',   // Off-white - Alternativo
  backgroundGray: '#F5F7FA',    // Cinza suave - Cards
  backgroundDark: '#0D47A1',    // Azul escuro - Dark mode
  backgroundCard: '#FFFFFF',    // Branco - Cards
  backgroundElevated: '#F8FAFC',// Elevado - Modais
  backgroundSection: '#F9FAFB', // Seções alternadas
  
  // Textos Profissionais
  textPrimary: '#0F172A',       // Quase preto - Textos principais
  textSecondary: '#475569',     // Slate - Textos secundários
  textTertiary: '#64748B',      // Slate claro - Metadados
  textLight: '#FFFFFF',         // Branco - Texto em fundos escuros
  textDark: '#1E293B',          // Dark - Alternativo
  textMuted: '#94A3B8',         // Muted - Placeholders
  textDisabled: '#CBD5E1',      // Disabled
  
  // Bordas
  border: '#E2E8F0',            // Bordas principais
  borderLight: '#F1F5F9',       // Bordas sutis
  borderDark: '#CBD5E1',        // Bordas enfáticas
  borderFocus: '#FF9800',       // Focus - Laranja
  borderHover: '#D1D5DB',       // Hover state
  
  // Semânticas
  success: '#4CAF50',           // Verde
  successLight: '#C8E6C9',      // Verde claro
  successDark: '#388E3C',       // Verde escuro
  error: '#F44336',             // Vermelho
  errorLight: '#FFCDD2',        // Vermelho claro
  errorDark: '#D32F2F',         // Vermelho escuro
  warning: '#FF9800',           // Laranja
  warningLight: '#FFE0B2',      // Laranja claro
  warningDark: '#F57C00',       // Laranja escuro
  info: '#03A9F4',              // Azul claro
  infoLight: '#B3E5FC',         // Azul muito claro
  infoDark: '#0288D1',          // Azul claro escuro
  rating: '#FF9800',            // Laranja para avaliações
  
  // Overlays
  overlay: 'rgba(13, 71, 161, 0.6)',
  overlayLight: 'rgba(13, 71, 161, 0.3)',
  overlayDark: 'rgba(13, 71, 161, 0.85)',
  overlayGradient: 'linear-gradient(180deg, rgba(13, 71, 161, 0) 0%, rgba(13, 71, 161, 0.75) 100%)',
  
  // Gradientes - Azul e Laranja
  gradientPrimary: ['#1976D2', '#0D47A1'],        // Azul
  gradientAccent: ['#FF9800', '#F57C00'],         // Laranja
  gradientNeutral: ['#F5F7FA', '#E2E8F0'],        // Neutro
  gradientSuccess: ['#4CAF50', '#388E3C'],        // Verde
  gradientHero: ['#1976D2', '#1565C0'],           // Hero sections
  gradientSubtle: ['#FAFBFD', '#F5F7FA'],         // Sutil
  gradientDark: ['#0D47A1', '#1565C0'],           // Escuro
  gradientShimmer: ['#FFFFFF', '#F8FAFC'],        // Shimmer
  gradientLight: ['#03A9F4', '#4FC3F7'],          // Azul claro
  
  // Backwards compatibility
  gradientTwilight: ['#1976D2', '#0D47A1'],
  gradientTwilightReverse: ['#0D47A1', '#1976D2'],
  gradientSunset: ['#FF9800', '#F57C00'],
  gradientPurple: ['#1976D2', '#0D47A1'],
  gradientBlue: ['#1976D2', '#1565C0'],
  gradientAurora: ['#1976D2', '#1565C0'],
  gradientSky: ['#03A9F4', '#0288D1'],
  gradientPremiumViolet: ['#1976D2', '#0D47A1'],
  gradientPremiumOcean: ['#03A9F4', '#0288D1'],
  gradientPremiumCoral: ['#FF9800', '#F57C00'],
  gradientPremiumEmerald: ['#4CAF50', '#388E3C'],
  gradientPremiumRose: ['#F44336', '#D32F2F'],
  gradientPremiumAmber: ['#FF9800', '#F57C00'],
  gradientMagic: ['#1976D2', '#1565C0'],
  gradientNeon: ['#03A9F4', '#4FC3F7'],
  
  // Glass Effects
  glass: {
    white: 'rgba(255, 255, 255, 0.95)',
    light: 'rgba(255, 255, 255, 0.85)',
    medium: 'rgba(255, 255, 255, 0.7)',
    dark: 'rgba(13, 71, 161, 0.9)',
    primary: 'rgba(25, 118, 210, 0.1)',
    ultraLight: 'rgba(255, 255, 255, 0.5)',
    frost: 'rgba(255, 255, 255, 0.75)',
    smoke: 'rgba(0, 0, 0, 0.05)',
  },
  
  // Sombras
  shadow: {
    primary: 'rgba(25, 118, 210, 0.12)',
    accent: 'rgba(255, 152, 0, 0.2)',
    dark: 'rgba(13, 71, 161, 0.1)',
    colored: 'rgba(25, 118, 210, 0.15)',
    soft: 'rgba(13, 71, 161, 0.06)',
  },
};

// DESIGN SYSTEM PROFISSIONAL - Inspirado Petz
export const Spacing = {
  xs: 4,      // Gaps mínimos, badges
  sm: 8,      // Gaps entre elementos relacionados
  md: 12,     // Padding interno de componentes
  lg: 16,     // Margin entre componentes
  xl: 20,     // Margin entre seções pequenas
  xxl: 24,    // Padding de cards principais
  xxxl: 32,   // Margin entre seções grandes
  huge: 40,   // Padding de containers principais
  massive: 48,// Espaçamento hero sections
  xl2: 56,    // Hero padding extra
};

// Border Radius Profissional - Mais Corporate
export const BorderRadius = {
  xs: 4,      // Badges, tags pequenas
  sm: 6,      // Botões pequenos, inputs compactos
  md: 10,     // Botões padrão, inputs, cards pequenos
  lg: 14,     // Cards médios, modais
  xl: 18,     // Cards grandes, containers
  xxl: 24,    // Elementos especiais (máximo para superfícies)
  round: 999, // Pills, chips, avatares circulares
};

// Tamanhos de Fonte Profissionais - Escala Refinada
export const FontSizes = {
  xs: 12,        // Captions, metadados
  sm: 14,        // Body small, descrições
  md: 16,        // Body base, textos principais
  lg: 18,        // Subtítulos (h6)
  xl: 20,        // Títulos pequenos (h5)
  xxl: 24,       // Títulos médios (h4)
  xxxl: 28,      // Títulos grandes (h3)
  huge: 34,      // Headers principais (h2)
  massive: 42,   // Hero titles (h1)
  displayMD: 36, // Display médio
  displayLG: 42, // Display grande
  displayXL: 52, // Display extra grande
};

// Pesos de Fonte Profissionais
export const FontWeights = {
  regular: '400',   // Textos normais, body
  medium: '500',    // Ênfase leve, labels
  semibold: '600',  // Subtítulos, botões
  bold: '700',      // Apenas para hero headings
};

// Line Heights Profissionais
export const LineHeights = {
  tight: 1.15,    // Display, hero titles
  snug: 1.3,      // Headings h1-h4
  normal: 1.45,   // Body text, base
  relaxed: 1.6,   // Long-form content
};

export const Shadows = {
  // Sombras Profissionais - Sutis e Elegantes
  xs: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 2,
    elevation: 1,
  },
  small: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  medium: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  large: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
  },
  xl: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 10,
  },
  xxl: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.14,
    shadowRadius: 28,
    elevation: 14,
  },
  // Sombras com Cor - Agora com Navy e Dourado
  colored: {
    shadowColor: '#1B2A4A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  accent: {
    shadowColor: '#FDBA21',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 5,
  },
  // Backwards compatibility
  twilight: {
    shadowColor: '#1B2A4A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  glow: {
    shadowColor: '#FDBA21',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 6,
  },
  premiumMulti: {
    shadowColor: '#1B2A4A',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 8,
  },
  premiumSoft: {
    shadowColor: '#475569',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 3,
  },
  premiumFloating: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.12,
    shadowRadius: 32,
    elevation: 12,
  },
};

// Animações Profissionais - Rápidas e Sutis
export const Animations = {
  micro: 120,       // Micro-interações
  swift: 180,       // Transições rápidas
  base: 240,        // Duração base
  deliberate: 320,  // Movimentos deliberados
  modal: 400,       // Modais e overlays
  shimmer: 2000,    // Efeitos de loop (shimmer, loading)
};

export const Motion = {
  // Easing Profissional - Suave mas Preciso
  easing: {
    easeOut: 'cubic-bezier(0.17, 0.67, 0.4, 0.97)',      // Entrances
    easeInOut: 'cubic-bezier(0.45, 0, 0.4, 1)',          // Modais
    easeIn: 'cubic-bezier(0.4, 0.0, 1, 1)',              // Exits
    sharp: 'cubic-bezier(0.4, 0.0, 0.6, 1)',             // Snappy
    smooth: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',      // Smooth
  },
  // Durações (sincronizado com Animations)
  duration: {
    micro: 120,
    swift: 180,
    base: 240,
    deliberate: 320,
    modal: 400,
    shimmer: 2000,
  },
  // Springs Profissionais - Sutis
  spring: {
    gentle: { damping: 18, stiffness: 220 },    // Padrão profissional
    smooth: { damping: 22, stiffness: 240 },    // Extra suave
    snappy: { damping: 16, stiffness: 260 },    // Responsivo
  },
  // Transições Predefinidas
  transition: {
    fade: { duration: 240, easing: 'ease-in-out' },
    slide: { duration: 320, easing: 'ease-out' },
    scale: { duration: 180, easing: 'ease-out' },
    shimmer: { duration: 2000, easing: 'linear' },
  },
};

export const Breakpoints = {
  small: 320,
  medium: 375,
  large: 414,
  tablet: 768,
  desktop: 1024,
};

export const Layout = {
  screenPadding: Spacing.lg,
  cardPadding: Spacing.lg,
  headerHeight: 64,
  tabBarHeight: 68,
  maxWidth: 600,
  minTouchTarget: 44,
  iconSize: {
    xs: 16,
    sm: 20,
    md: 24,
    lg: 32,
    xl: 40,
    xxl: 48,
  },
  elevation: {
    flat: 0,
    low: 2,
    medium: 4,
    high: 8,
    highest: 16,
  },
};

// Tipografia Profissional - Hierarquia Clara
export const Typography = {
  // Display (52px) - Hero Titles
  display: {
    fontSize: FontSizes.displayXL,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.5,
  },
  // H1 (42px) - Page Titles
  h1: {
    fontSize: FontSizes.massive,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.5,
  },
  // H2 (34px) - Section Titles
  h2: {
    fontSize: FontSizes.huge,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.snug,
    letterSpacing: -0.25,
  },
  // H3 (28px) - Subsection Titles
  h3: {
    fontSize: FontSizes.xxxl,
    fontWeight: FontWeights.semibold,
    lineHeight: LineHeights.snug,
    letterSpacing: -0.25,
  },
  // H4 (24px) - Card Titles
  h4: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.semibold,
    lineHeight: LineHeights.snug,
    letterSpacing: 0,
  },
  // H5 (20px) - Small Headings
  h5: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.semibold,
    lineHeight: LineHeights.snug,
    letterSpacing: 0,
  },
  // H6 (18px) - Subtle Headings
  h6: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.medium,
    lineHeight: LineHeights.normal,
    letterSpacing: 0,
  },
  // Body (16px) - Base Text
  body: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.normal,
    letterSpacing: 0,
  },
  // Body Small (14px) - Secondary Text
  bodySmall: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.normal,
    letterSpacing: 0,
  },
  // Caption (12px) - Metadata
  caption: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.snug,
    letterSpacing: 0,
  },
  // Label (14px uppercase) - Form Labels, Tags
  label: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.medium,
    lineHeight: LineHeights.snug,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  // Backwards compatibility
  displayXL: {
    fontSize: FontSizes.displayXL,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.5,
  },
  displayLG: {
    fontSize: FontSizes.displayLG,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.5,
  },
  displayMD: {
    fontSize: FontSizes.displayMD,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.snug,
    letterSpacing: -0.25,
  },
  bodyLarge: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.normal,
    letterSpacing: 0,
  },
};

// Glassmorphism Profissional - Simplificado (usar com moderação)
export const Glassmorphism = {
  // Overlay - Para sobreposições escuras
  overlay: {
    backgroundColor: 'rgba(15, 23, 42, 0.5)',
    backdropFilter: 'blur(12px)',
    borderWidth: 0,
  },
  // Frosting - Para efeitos sutis de vidro (opcional)
  frosting: {
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    backdropFilter: 'blur(16px)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  // Valores legados (deprecated - usar sólidos)
  light: {
    backgroundColor: Colors.backgroundCard,
  },
  medium: {
    backgroundColor: Colors.backgroundGray,
  },
  dark: {
    backgroundColor: Colors.backgroundDark,
  },
};

export const FluidSpacing = (screenWidth) => {
  const baseWidth = 375;
  const scale = screenWidth / baseWidth;
  
  return {
    xs: Math.max(4, Spacing.xs * scale),
    sm: Math.max(6, Spacing.sm * scale),
    md: Math.max(10, Spacing.md * scale),
    lg: Math.max(14, Spacing.lg * scale),
    xl: Math.max(18, Spacing.xl * scale),
    xxl: Math.max(22, Spacing.xxl * scale),
    xxxl: Math.max(28, Spacing.xxxl * scale),
  };
};
