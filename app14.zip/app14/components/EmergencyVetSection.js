import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

export default function EmergencyVetSection({ onCallPress, onChatPress }) {
  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#FF6B6B', '#EE5A52']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.gradient}
      >
        <View style={styles.content}>
          <View style={styles.header}>
            <View style={styles.iconPulse}>
              <View style={styles.pulse1} />
              <View style={styles.pulse2} />
              <View style={styles.iconContainer}>
                <Ionicons name="medical" size={32} color={Colors.textLight} />
              </View>
            </View>
            
            <View style={styles.headerText}>
              <View style={styles.liveIndicator}>
                <View style={styles.liveDot} />
                <Text style={styles.liveText}>DISPONÍVEL AGORA</Text>
              </View>
              <Text style={styles.title}>Emergência Veterinária 24h</Text>
              <Text style={styles.subtitle}>
                Veterinários de plantão prontos para atender seu pet
              </Text>
            </View>
          </View>

          <View style={styles.buttonsContainer}>
            <TouchableOpacity
              style={styles.button}
              onPress={onCallPress}
              activeOpacity={0.9}
            >
              <Ionicons name="call" size={20} color={Colors.error} />
              <Text style={styles.buttonText}>Ligar Agora</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.button, styles.buttonSecondary]}
              onPress={onChatPress}
              activeOpacity={0.9}
            >
              <Ionicons name="chatbubbles" size={20} color={Colors.textLight} />
              <Text style={[styles.buttonText, styles.buttonTextSecondary]}>
                Chat Online
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.infoRow}>
            <View style={styles.infoItem}>
              <Ionicons name="time" size={16} color={Colors.textLight} />
              <Text style={styles.infoText}>Resposta em 2min</Text>
            </View>
            <View style={styles.infoItem}>
              <Ionicons name="shield-checkmark" size={16} color={Colors.textLight} />
              <Text style={styles.infoText}>Profissionais certificados</Text>
            </View>
          </View>
        </View>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
    marginHorizontal: Spacing.lg,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    ...Shadows.large,
  },
  gradient: {
    padding: Spacing.xl,
  },
  content: {
    gap: Spacing.lg,
  },
  header: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  iconPulse: {
    position: 'relative',
    width: 72,
    height: 72,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulse1: {
    position: 'absolute',
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.textLight,
    opacity: 0.2,
  },
  pulse2: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: Colors.textLight,
    opacity: 0.3,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.textLight,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.medium,
  },
  headerText: {
    flex: 1,
    justifyContent: 'center',
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: Spacing.xs,
  },
  liveDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.textLight,
  },
  liveText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
    letterSpacing: 0.5,
  },
  title: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: FontSizes.sm,
    color: Colors.textLight,
    opacity: 0.9,
    lineHeight: 18,
  },
  buttonsContainer: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  button: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.textLight,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    gap: Spacing.xs,
    ...Shadows.small,
  },
  buttonSecondary: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderWidth: 1.5,
    borderColor: Colors.textLight,
  },
  buttonText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.error,
  },
  buttonTextSecondary: {
    color: Colors.textLight,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  infoText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
  },
});
