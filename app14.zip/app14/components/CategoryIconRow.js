import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import PressableScale from './PressableScale';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows } from '../constants/theme';

const ICON_MAP = {
  'water': 'water',
  'medical': 'medical',
  'storefront': 'storefront-outline',
  'medkit': 'medkit',
  'walk': 'walk',
  'school': 'school',
  'warning': 'warning',
};

const CategoryIcon = ({ category, onPress }) => {
  return (
    <PressableScale onPress={() => onPress(category)} style={styles.categoryItem}>
      <LinearGradient
        colors={[category.color, category.color + 'CC']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.iconContainer}
      >
        <Ionicons 
          name={ICON_MAP[category.icon] || 'apps'} 
          size={24} 
          color={Colors.textLight} 
        />
      </LinearGradient>
      
      <Text style={styles.categoryName} numberOfLines={2}>
        {category.name}
      </Text>
    </PressableScale>
  );
};

const CategoryIconRow = ({ categories, onCategoryPress }) => {
  return (
    <View style={styles.container}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        bounces={false}
      >
        {categories.map((category, index) => (
          <View
            key={category.id}
            style={[
              styles.categoryWrapper,
              index === 0 && styles.firstCategory,
              index === categories.length - 1 && styles.lastCategory,
            ]}
          >
            <CategoryIcon category={category} onPress={onCategoryPress} />
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: Spacing.md,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  categoryWrapper: {
    alignItems: 'center',
  },
  firstCategory: {
    marginLeft: 0,
  },
  lastCategory: {
    marginRight: Spacing.lg,
  },
  categoryItem: {
    alignItems: 'center',
    width: 72,
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.xs,
    ...Shadows.small,
  },
  categoryName: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    textAlign: 'center',
    lineHeight: 14,
  },
});

export default CategoryIconRow;
