import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import Animated, { 
  useAnimatedStyle, 
  interpolate, 
  Extrapolate 
} from 'react-native-reanimated';
import { Colors, Spacing, FontSizes, FontWeights, Shadows, BorderRadius } from '../constants/theme';

const HeaderLocation = ({ 
  location, 
  onLocationPress, 
  onNotificationPress, 
  hasNotification = false,
  scrollY 
}) => {
  const headerAnimatedStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 50],
      [0, 1],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollY.value,
      [0, 50],
      [1, 0.95],
      Extrapolate.CLAMP
    );

    return {
      backgroundColor: `rgba(255, 255, 255, ${opacity * 0.95})`,
      transform: [{ scale }],
    };
  });

  const contentAnimatedStyle = useAnimatedStyle(() => {
    const translateY = interpolate(
      scrollY.value,
      [0, 50],
      [0, -2],
      Extrapolate.CLAMP
    );

    return {
      transform: [{ translateY }],
    };
  });

  return (
    <Animated.View style={[styles.container, headerAnimatedStyle]}>
      <View style={styles.content}>
        <Animated.View style={[styles.locationContainer, contentAnimatedStyle]}>
          <TouchableOpacity 
            style={styles.locationButton} 
            onPress={onLocationPress}
            activeOpacity={0.7}
          >
            <LinearGradient
              colors={Colors.gradientTwilight}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.locationIconContainer}
            >
              <Ionicons name="location" size={18} color={Colors.textLight} />
            </LinearGradient>
            
            <View style={styles.locationTextContainer}>
              <Text style={styles.locationLabel}>Entregar em</Text>
              <View style={styles.locationRow}>
                <Text style={styles.locationText} numberOfLines={1}>
                  {location}
                </Text>
                <Ionicons 
                  name="chevron-down" 
                  size={16} 
                  color={Colors.primary} 
                  style={styles.chevron}
                />
              </View>
            </View>
          </TouchableOpacity>
        </Animated.View>

        <Animated.View style={[styles.actionsContainer, contentAnimatedStyle]}>
          <TouchableOpacity 
            style={[styles.iconButton, styles.favoriteButton]} 
            onPress={() => console.log('Favorites')}
            activeOpacity={0.7}
          >
            <Ionicons name="heart-outline" size={22} color={Colors.textPrimary} />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.iconButton} 
            onPress={onNotificationPress}
            activeOpacity={0.7}
          >
            {hasNotification && <View style={styles.notificationBadge} />}
            <Ionicons name="notifications-outline" size={22} color={Colors.textPrimary} />
          </TouchableOpacity>
        </Animated.View>
      </View>

      <View style={styles.bottomBorder} />
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: Platform.OS === 'ios' ? 0 : Spacing.md,
    paddingBottom: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    ...Shadows.small,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
  },
  locationContainer: {
    flex: 1,
    marginRight: Spacing.md,
  },
  locationButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationIconContainer: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.sm,
    ...Shadows.colored,
  },
  locationTextContainer: {
    flex: 1,
  },
  locationLabel: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
    marginBottom: 2,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    flex: 1,
  },
  chevron: {
    marginLeft: 2,
  },
  actionsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  iconButton: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.backgroundElevated,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  favoriteButton: {
    backgroundColor: Colors.primaryLight,
    borderColor: Colors.primary + '20',
  },
  notificationBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.error,
    borderWidth: 1.5,
    borderColor: Colors.backgroundLight,
  },
  bottomBorder: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: Colors.border,
  },
});

export default HeaderLocation;
