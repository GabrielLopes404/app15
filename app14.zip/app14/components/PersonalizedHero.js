import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  withSpring,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Typography, Motion } from '../constants/theme';
import { useResponsiveLayout } from '../hooks/useResponsiveLayout';

const { width } = Dimensions.get('window');

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);
const AnimatedLinearGradient = Animated.createAnimatedComponent(LinearGradient);

export default function PersonalizedHero({ 
  userName = 'Usuário',
  onCTAPress,
  title = 'Descubra o melhor\npara seu pet',
  subtitle = 'Produtos, serviços e cuidados especiais',
  ctaText = 'Explorar agora',
}) {
  const { scaleFont, spacing, isXS } = useResponsiveLayout();
  
  const shimmerTranslate = useSharedValue(-width);
  const gradientRotate = useSharedValue(0);
  const ctaScale = useSharedValue(1);

  useEffect(() => {
    shimmerTranslate.value = withRepeat(
      withSequence(
        withTiming(width, { duration: 2000, easing: Easing.linear }),
        withTiming(-width, { duration: 0 })
      ),
      -1,
      false
    );

    gradientRotate.value = withRepeat(
      withTiming(360, { duration: 20000, easing: Easing.linear }),
      -1,
      false
    );
  }, []);

  const shimmerAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: shimmerTranslate.value }],
  }));

  const gradientAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${gradientRotate.value}deg` }],
  }));

  const ctaAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: ctaScale.value }],
  }));

  const handleCTAPressIn = () => {
    ctaScale.value = withSpring(0.95, Motion.spring.snappy);
  };

  const handleCTAPressOut = () => {
    ctaScale.value = withSpring(1, Motion.spring.bouncy);
  };

  return (
    <View style={styles.container}>
      <View style={[styles.gradientContainer, { backgroundColor: Colors.primary }]}>
        <View style={[styles.gradient, { opacity: 0.95 }]} />
        
        <View style={[styles.overlay, { backgroundColor: 'rgba(0,0,0,0.15)' }]} />
      </View>

      <View style={[styles.content, { padding: spacing.lg }]}>
        <View style={styles.greetingBadge}>
          <Ionicons name="sparkles" size={14} color={Colors.primary} />
          <Text style={styles.greetingText}>Olá, {userName}!</Text>
        </View>

        <Text style={[
          styles.title,
          { 
            fontSize: scaleFont(isXS ? FontSizes.xxxl : FontSizes.huge),
            lineHeight: isXS ? 34 : 42
          }
        ]}>
          {title}
        </Text>

        <Text style={[styles.subtitle, { fontSize: isXS ? FontSizes.md : FontSizes.lg }]}>
          {subtitle}
        </Text>

        <AnimatedTouchable
          style={[styles.ctaButton, ctaAnimatedStyle]}
          activeOpacity={0.9}
          onPress={onCTAPress}
          onPressIn={handleCTAPressIn}
          onPressOut={handleCTAPressOut}
        >
          <View style={[styles.ctaGradient, { backgroundColor: Colors.textLight }]}>
            <Text style={styles.ctaText}>{ctaText}</Text>
            <Ionicons name="arrow-forward" size={20} color={Colors.primary} />
          </View>
        </AnimatedTouchable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    minHeight: 260,
    ...Shadows.premiumMulti,
  },
  gradientContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  gradient: {
    ...StyleSheet.absoluteFillObject,
    width: '200%',
    height: '200%',
    left: '-50%',
    top: '-50%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingVertical: Spacing.xxxl,
  },
  greetingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: Colors.textLight,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.round,
    marginBottom: Spacing.md,
    gap: Spacing.xs,
    ...Shadows.medium,
  },
  greetingText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  title: {
    ...Typography.displayMD,
    color: Colors.textLight,
    marginBottom: Spacing.md,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  subtitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.medium,
    color: 'rgba(255, 255, 255, 0.95)',
    marginBottom: Spacing.xl,
    lineHeight: 24,
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  ctaButton: {
    alignSelf: 'flex-start',
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    ...Shadows.large,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing.xl,
    gap: Spacing.sm,
    overflow: 'hidden',
  },
  shimmer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    width: 100,
  },
  ctaText: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.primary,
  },
});
