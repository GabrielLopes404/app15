import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function OfferCard({ offer, onPress }) {
  const timeLeft = '2h 15m';
  
  return (
    <TouchableOpacity
      style={styles.offerCard}
      onPress={onPress}
      activeOpacity={0.95}
    >
      <Image
        source={{ uri: offer.image }}
        style={styles.offerImage}
        resizeMode="cover"
      />
      
      <View style={styles.discountBadge}>
        <Text style={styles.discountText}>{offer.discount}% OFF</Text>
      </View>

      <View style={styles.timerBadge}>
        <Ionicons name="time-outline" size={12} color={Colors.textLight} />
        <Text style={styles.timerText}>{timeLeft}</Text>
      </View>
      
      <View style={styles.offerInfo}>
        <Text style={styles.offerTitle} numberOfLines={2}>{offer.title}</Text>
        <View style={styles.priceRow}>
          <Text style={styles.oldPrice}>R$ {offer.oldPrice.toFixed(2)}</Text>
          <Text style={styles.newPrice}>R$ {offer.newPrice.toFixed(2)}</Text>
        </View>
        <View style={styles.stockBar}>
          <View style={[styles.stockFill, { width: `${offer.stock}%` }]} />
        </View>
        <Text style={styles.stockText}>Apenas {offer.unitsLeft} restantes!</Text>
      </View>
    </TouchableOpacity>
  );
}

export default function SpecialOffersSection({ offers = [], onOfferPress }) {
  const defaultOffers = [
    {
      id: '1',
      title: 'Ração Premium Golden 15kg',
      discount: 40,
      oldPrice: 189.90,
      newPrice: 113.90,
      image: 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=500',
      stock: 35,
      unitsLeft: 12
    },
    {
      id: '2',
      title: 'Kit Banho e Tosa Completo',
      discount: 50,
      oldPrice: 120.00,
      newPrice: 60.00,
      image: 'https://images.unsplash.com/photo-1623387641168-d9803ddd3f35?w=500',
      stock: 60,
      unitsLeft: 8
    },
    {
      id: '3',
      title: 'Cama Ortopédica para Pets',
      discount: 35,
      oldPrice: 299.90,
      newPrice: 194.90,
      image: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=500',
      stock: 25,
      unitsLeft: 5
    }
  ];

  const displayOffers = offers.length > 0 ? offers : defaultOffers;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Ionicons name="flash" size={24} color={Colors.accent} />
          <Text style={styles.title}>Ofertas Relâmpago</Text>
        </View>
        <View style={styles.liveIndicator}>
          <View style={styles.liveDot} />
          <Text style={styles.liveText}>AO VIVO</Text>
        </View>
      </View>
      
      <Text style={styles.subtitle}>Aproveite antes que acabe!</Text>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {displayOffers.map((offer) => (
          <OfferCard
            key={offer.id}
            offer={offer}
            onPress={() => onOfferPress?.(offer)}
          />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xs,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  title: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.error,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
    gap: 4,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.textLight,
  },
  liveText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
    letterSpacing: 0.5,
  },
  subtitle: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  offerCard: {
    width: 200,
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    ...Shadows.medium,
  },
  offerImage: {
    width: '100%',
    height: 140,
    backgroundColor: Colors.backgroundGray,
  },
  discountBadge: {
    position: 'absolute',
    top: Spacing.sm,
    left: Spacing.sm,
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.md,
  },
  discountText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  timerBadge: {
    position: 'absolute',
    top: Spacing.sm,
    right: Spacing.sm,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  timerText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
  },
  offerInfo: {
    padding: Spacing.md,
  },
  offerTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
    minHeight: 40,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  oldPrice: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    textDecorationLine: 'line-through',
  },
  newPrice: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.accent,
  },
  stockBar: {
    height: 4,
    backgroundColor: Colors.backgroundGray,
    borderRadius: 2,
    marginBottom: Spacing.xs,
    overflow: 'hidden',
  },
  stockFill: {
    height: '100%',
    backgroundColor: Colors.accent,
  },
  stockText: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
  },
});
